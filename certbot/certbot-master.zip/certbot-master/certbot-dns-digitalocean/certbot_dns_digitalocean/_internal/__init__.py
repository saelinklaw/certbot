"""Internal implementation of `~certbot_dns_digitalocean.dns_digitalocean` plugin."""
